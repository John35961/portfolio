import AOS from 'aos'

AOS.init({
  once: true,
  offset: 50
});
